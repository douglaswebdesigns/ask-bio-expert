<?php

$terms = get_terms( 'category' );
if( $terms ) {
  echo '<ul class="category-menu">';
  foreach( $terms as $term ) {
    echo '<li><a href="' . get_term_link( $term, 'category' ) . '">' . $term->name . '</a></li>';
  }
  echo '</ul>';
}