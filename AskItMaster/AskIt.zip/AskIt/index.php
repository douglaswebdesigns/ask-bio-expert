<?php get_header(); ?>

<div id="main-area">
	<?php get_template_part('includes/breadcrumbs'); ?>

	<div id="main-recent">
		<?php get_template_part('includes/entry'); ?>
	</div> <!-- end #main-recent -->
</div> <!-- end #main-area -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>