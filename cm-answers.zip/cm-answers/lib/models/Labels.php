<?php

class CMA_Labels {
	
	static function getLocalized($msg) {
		return CMA::__($msg);
	}
	
}