<?php
global $wpdb;
$textdomain = 'custom-registration-form-builder-with-submission-manager';
$crf_submissions =$wpdb->prefix."crf_submissions";
$crf_fields =$wpdb->prefix."crf_fields";
$crf_forms =$wpdb->prefix."crf_forms";
$crf_stats =$wpdb->prefix."crf_stats";
$path =  plugin_dir_url(__FILE__); 

if(isset($_REQUEST['form_id']))
{
	$form_id = $_REQUEST['form_id'];		
}
else
{
	$qry = "select id from $crf_forms order by id asc limit 1";
    $reg = $wpdb->get_var($qry);
	$form_id = $_REQUEST['form_id']=$reg;
}

?>
    <div class="crf-main-form crf-main-form2">
    <div class="crf-chart-top">
    <form name="field_list" id="field_list" method="post">
    <div class="crf-form-name-heading-Submissions">
      <h1 class="fieldanalytics-icon"><?php _e('Field Analytics', $textdomain ); ?></h1>
    </div>
    <div  class="crf-add-remove-field-submissions crf-new-buttons">
      <select name="form_id" id="form_id" onChange="redirectform(this.value,'crf_field_stats')">
        <?php
    $qry = "select * from $crf_forms";
    $reg = $wpdb->get_results($qry);
    if(!empty($reg))
    {
        foreach($reg as $row)
        {
            ?>
        <option value="<?php echo $row->id;?>" <?php if($_REQUEST['form_id']==$row->id) echo 'selected';?>>
        <?php 
		$formnamelength = strlen($row->form_name);
if($formnamelength<=15){echo $row->form_name;}
else
{
$formnamehalf = substr($row->form_name, 0, 15);
echo $formnamehalf.'...';
}?>
        </option>
        <?php
        }
    }
    ?>
      </select>
      </div>
      
   </form>
   </div>
    <div class="cler"></div>
  	<div class="charts charts-2">
    <div class="charts-main-box">
<?php
$qry = "select * from $crf_fields where form_id ='".$form_id."' and Type in('radio','select','checkbox','country') order by ordering asc";
$reg = $wpdb->get_results($qry);
$i=1;
if(!empty($reg))
{
  foreach($reg as $row)
  {
	  $fieldoption = explode(',',$row->Option_Value);
	  $fieldname = sanitize_key($row->Name).'_'.$row->Id;
	  $entries = $wpdb->get_results( "SELECT * FROM $crf_submissions where form_id ='".$form_id."' and field = '".$fieldname."'");
	  foreach($entries as $entry)
	  {
		  $value = explode(',',$entry->value);
		  
		  //print_r($entry);die;
		  if(is_array($value))
		  {
			  foreach($value as $val)
			  {
				  $fieldvalues[]=$val;	
			  }
		  }
		  else
		  {
		  	$fieldvalues[] = $value;	
		  }
	  }
	  if(!empty($fieldvalues))
	  {
		  $fieldsubmission =  array_count_values($fieldvalues);
	  }
  ?>
  <script type="text/javascript">
		// Load the Visualization API and the piechart package.
		google.load('visualization', '1.0', {'packages':['corechart']});
		// Set a callback to run when the Google Visualization API is loaded.
		google.setOnLoadCallback(drawChart);
		// Callback that creates and populates a data table,
		// instantiates the pie chart, passes in the data and
		// draws it.
		function drawChart() {
		  // Create the data table.
		  var data = new google.visualization.DataTable();
		  data.addColumn('string', 'Options');
		  data.addColumn('number', 'Submissions');
		  data.addRows([
				 <?php
				//for geochart
			   foreach($fieldsubmission as $key=>$data)
			   {
				  echo  "['".$key."', ".$data."],";
			   }
				?>
		  ['Other', 0]
		  ]);
		  // Set chart options
		  var options = {
		  is3D: true,
						 'width':400,
						 'height':300,'colors': ['#4eb7b5', '#b9e2e0', '#ff6c6c', '#ff9d9d', '#ffd4d4','#e39797','#e05757','#c4a7ef','#f7edb8','#dbecc3']};
		  // Instantiate and draw our chart, passing in some options.
		  var chart = new google.visualization.PieChart(document.getElementById('field_div<?php echo $i;?>'));
		  chart.draw(data, options);
		}
	  </script>
	  <div class="main-chat <?php if($i%2==0)echo 'crf_main_chart_even';else{echo 'crf_main_chart_odd';}?>">
	  <h1 class="chat-hedding"><?php echo $row->Name;?><span class="icon"></span></h1>
	  <div class="chartdiv" id="field_div<?php echo $i;?>"></div>
	  </div>
  <?php	
  $i++;
  unset($fieldsubmission);
  unset($fieldoption);
  unset($fieldvalues);
	}
}
else
{?><div class="cols" style="background:white; padding:5px;"> 
<?php
	 _e('No data found for analysis. This could happen if there are not enough submissions or if the form does not contains statistical fields like checkbox or radio button.', $textdomain );
?></div>
<?php
}
?>

<div class="cler"></div>
 </div>
 </div>
 <div class="cler"></div>
 </div>
