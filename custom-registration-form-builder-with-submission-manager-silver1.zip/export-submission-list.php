<?php 
/*Controls custom field creation in the dashboard area*/
global $wpdb;
$textdomain = 'custom-registration-form-builder-with-submission-manager';
$filename = '../custom-registration-form-with-submission-manager.xls';
include_once 'crf_functions.php';
$crf_submissions =$wpdb->prefix."crf_submissions";
$crf_fields =$wpdb->prefix."crf_fields";
$crf_forms =$wpdb->prefix."crf_forms";
$path =  plugin_dir_url(__FILE__); 


// Write column names
if(isset($_REQUEST['formid']) && $_REQUEST['formid']!="")
{
	$qry = "select * from $crf_fields where form_id ='".$_REQUEST['formid']."' and Type not in('heading','paragraph') order by ordering asc";
	$reg = $wpdb->get_results($qry);
	
	$totalentryqry = "SELECT distinct(submission_id)  FROM $crf_submissions where form_id =".$_REQUEST['formid'];
 
  if(isset($_REQUEST['crf_filter_result']))
  {
	if($_REQUEST['start_date']!="" && $_REQUEST['end_date']!="")
	{
		$startdate = date_create($_REQUEST['start_date']);
		$startdate =  date_format($startdate, 'U');
		
		$enddate = date_create($_REQUEST['end_date']);
		$enddate =  date_format($enddate, 'U');
		
	$totalentryqry .=" and `field` = 'entry_time' and `value` between '".$startdate."' and '".$enddate."'";
	}
	if($_REQUEST['field_name']!="" && $_REQUEST['field_value']!="")
	{
	$totalentryqry .=" and submission_id in(select distinct(submission_id) FROM wp_crf_submissions where `field` = '".$_REQUEST['field_name']."' and `value` like '%".$_REQUEST['field_value']."%') ";	
	}
	if($_REQUEST['field_name']=="" && $_REQUEST['field_value']!="")
	{
	$totalentryqry .=" and submission_id in(select distinct(submission_id) FROM wp_crf_submissions where `value` like '%".$_REQUEST['field_value']."%') ";	
	}
	
  }
  
  $entries = $wpdb->get_results($totalentryqry);

	$form_type = crf_get_form_option_value('form_type',$_REQUEST['formid']);
}
$table = '<table class="wp-list-table widefat fixed" cellspacing="0">
  <thead>
    <tr>';
	if($form_type=='reg_form')
	{
		$table .='<th scope="col" style="">User Name</th>';
		$table .='<th scope="col" style="">User Email</th>';
	}
	foreach($reg as $row)
	{
 	$table .='<th scope="col" style="">'.$row->Name.'</th>';
	}
   
   $table .=' </tr>
  </thead>
  <tfoot>
     
  </tfoot>
  <tbody id="the-list">';
 
  $i=1;
  foreach($entries as $entry)
  {
	if($i%2==0)
	{
		$class="";
	}
	else
	{
		$class="alternate";
	}
	 $table .= '<tr class="'.$class.'">';
	 $submission_id = $entry->submission_id;
	// echo $submission_id;die;
	// crf_submision_field_value($submission_id,'user_name');
	 
	 if($form_type=='reg_form')
	{
		$table .='<th scope="row" style="">'.crf_submision_field_value($submission_id,'user_name').'</th>';
		$table .='<th scope="row" style="">'.crf_submision_field_value($submission_id,'user_email').'</th>';
	}
	foreach($reg as $row)
	{
	  $key = crf_get_field_key($row);
	  $result = crf_submision_field_value($submission_id,$key);
	  $Customfield = $row->Name;
	  //echo $Customfield;die;
	  
	  if(is_array($result))
	  {
		  $result = implode(',',$result);
	  }   
	  /*file addon start */
	  if($row->Type=='file')
	  {
			$fileeid = explode(',',$result);
			foreach($fileeid as $file)
			{
				$file_title[] = wp_get_attachment_url( $file );
			}
			$result = implode(',',$file_title);
			unset($file_title);
	  }
	  /*file addon end */
	   $table .='<th scope="row" style="">'.$result.'</th>';
	} 
	$table .='</tr>';
$i++;
} 
    
$table .='  </tbody>
</table>';
$table = iconv("UTF-8","UTF-16", $table);
file_put_contents($filename,$table);
wp_redirect($filename);
?>