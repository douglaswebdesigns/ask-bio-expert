<?php
	/*  PHP Document                               */
	/*  Code to include in the functions.php file  */
	
	
		
	/* This file is intentionally blank - we'll build this file during the course */


?>