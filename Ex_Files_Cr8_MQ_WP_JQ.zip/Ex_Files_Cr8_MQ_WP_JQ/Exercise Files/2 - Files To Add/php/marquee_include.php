<?php
	/*  PHP Document                           */
	/*  Code to include in the index.php file  */
	


	/* This file is intentionally blank - we'll build this file during the course */


?>